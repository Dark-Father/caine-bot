Rolls successes vs difficulty on 10-sided dice utilizing Vampire the Masquerade, V20 system.

