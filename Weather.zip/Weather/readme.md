Weather Control system for Minerva.

The plugin is working, but it need to make it a little fancier with colors and stuff.

Note: You'll need an API key to auth it correctly against OpenWeatherMap. This plugin only handles one particular city.
